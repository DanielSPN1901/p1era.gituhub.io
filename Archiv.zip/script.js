document.addEventListener('DOMContentLoaded', () => {

    // --- Smooth Scrolling für interne Links ---
    const internalLinks = document.querySelectorAll('a[href^="#"]');
    internalLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault(); // Standard-Ankerverhalten verhindern
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                // Berücksichtige die Höhe des fixierten Headers
                const headerOffset = document.querySelector('header')?.offsetHeight || 60;
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: "smooth" // Sanftes Scrollen
                });
            }
        });
    });

    // --- Fade-in Effekt beim Scrollen ---
    const fadeElements = document.querySelectorAll('.fade-in-section');

    if ('IntersectionObserver' in window) { // Prüfen, ob IntersectionObserver unterstützt wird
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    // Optional: Beobachtung beenden, nachdem Element sichtbar wurde
                    // observer.unobserve(entry.target);
                }
                // Optional: Effekt rückgängig machen, wenn Element wieder aus dem Viewport verschwindet
                // else {
                //     entry.target.classList.remove('is-visible');
                // }
            });
        }, {
            threshold: 0.1 // Element wird als sichtbar betrachtet, wenn 10% davon im Viewport sind
        });

        fadeElements.forEach(el => {
            observer.observe(el);
        });
    } else {
        // Fallback für ältere Browser: Alle Elemente sofort anzeigen
        fadeElements.forEach(el => el.classList.add('is-visible'));
    }

    // --- Optional: Kontaktformular-Handler (Nur Frontend-Teil) ---
    const contactForm = document.getElementById('contact-form');
    if (contactForm && contactForm.getAttribute('action') === 'DEINE_BACKEND_URL') {
        // Wenn du KEINEN Backend-Service nutzt, kannst du diesen Teil entfernen
        // oder anpassen, z.B. für eine Meldung, dass der Mailto-Link genutzt werden soll.
        console.warn("Kontaktformular benötigt eine Backend-URL oder einen Service wie Formspree, um E-Mails zu senden. Aktuell ist 'DEINE_BACKEND_URL' als Platzhalter gesetzt.");

        contactForm.addEventListener('submit', (e) => {
             // Hier könntest du Frontend-Validierung hinzufügen bevor gesendet wird
             // Beispiel: if (!validateForm()) e.preventDefault();
             // Wenn KEIN Backend vorhanden ist und du den mailto-Link bevorzugst,
             // verhindere das Senden hier komplett und zeige eine Meldung.
             // e.preventDefault();
             // alert("Bitte nutzen Sie den 'Direkt E-Mail schreiben'-Link.");
        });
    }


}); // Ende DOMContentLoaded